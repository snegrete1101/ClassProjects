#Sebastian Negrete-Alamillo
#CSCI 101 - Section D
#Create Project - Py-Tac-Toe


import random
import time

def display(): #Creates board that shows the locations of the player's moves
    print(" %s | %s | %s " % (cells[1],cells[2],cells[3]))
    print("===========")
    print(" %s | %s | %s " % (cells[4],cells[5],cells[6]))
    print("===========")
    print(" %s | %s | %s " % (cells[7],cells[8],cells[9]))

def reset(): # Creates the board displaying valid board locations
    print('\nWelcome to Py-Tac-Toe!\n\nThe board is set up as the board below follows, use the numbers to choose a place on the board')
    with open('board.txt', 'r') as board:
        a = board.read()
        print(a)

def get_xinput(): # Returns valid location on the board
    try:
        x_index = int(input('\nPlayer 1 choose an empty location on the board \nLocation> '))
        if 1 <= x_index <= 9:
            return x_index
        else:
            print('Please select a valid number from 1-9.')
            return get_xinput()
    except ValueError:
        print('\nPlease choose a valid location 1-9 on the board.')
        return get_xinput()
        

def get_oinput(): # Returns valid location on the board
    try:
        o_index = int(input('Player 2 choose an empty location on the board \nLocation> '))
        if 1 <= x_index <= 9:
            return o_index
        else:
            print('Please select a valid number from 1-9.')
            return get_oinput()
    except ValueError:
        print('\nPlease choose a valid location 1-9 on the board.')
        return get_oinput()
        
def update_x(index): # checks validity of the player's selection and displays the new board
    if (cells[index] != 'X') and (cells[index] != 'O'):
        cells[index] = 'X'
        print('\n')
        return display()
    else:
        print('Please select an unoccupied space on the board')
        x = get_xinput()
        return update_x(x)

def update_o(index): # checks validity of player's or bot's selection and displays the new board
    if (cells[index] != 'X') and (cells[index] != 'O'):
        cells[index] = 'O'
        print('\n')
        return display()
    else:
        if players == 1:
            if diff == 'e':
                o = easy_bot()
                return update_o(o)
            elif diff == 'h':
                o = hard_bot()
                return update_o(o)
        elif players == 2:
            print('Please select an unoccupied space on the board')
            o = get_oinput()
            return update_o(o)

def check(a): # checks the list for any and all possible winning combinations
    if a in cells[1] and a in cells[2] and a in cells[3]:
        return True
    elif a in cells[1] and a in cells[5] and a in cells[9]:
        return True
    elif a in cells[1] and a in cells[4] and a in cells[7]:
        return True
    elif a in cells[3] and a in cells[6] and a in cells[9]:
        return True
    elif a in cells[3] and a in cells[5] and a in cells[7]:
        return True
    elif a in cells[4] and a in cells[5] and a in cells[6]:
        return True
    elif a in cells[7] and a in cells[8] and a in cells[9]:
        return True
    elif a in cells[2] and a in cells[5] and a in cells[8]:
        return True
    else:
        return False    
       

def easy_bot(): # creates bot moves that is easy to beat since it is dumb
    index = random.randint(1,9)
    return index

def hard_bot(): # creates bot moves that are more knowledgeable of tic-tac-toe and analyze gameboard
    if ' ' in cells[5]:
        return 5
    elif 'X' in cells[1] and 'X' in cells[4] and ' ' in cells[7]:
        return 7
    elif 'X' in cells[1] and 'X' in cells[2] and ' ' in cells[3]:
        return 3
    elif 'X' in cells[1] and 'X' in cells[5] and ' ' in cells[9]:
        return 9
    elif 'X' in cells[1] and 'X' in cells[7] and ' ' in cells[4]:
        return 4
    elif 'X' in cells[1] and 'X' in cells[3] and ' ' in cells[2]:
        return 2
    elif 'O' in cells[4] and 'O' in cells[5] and ' ' in cells[6]:
        return 6
    elif 'X' in cells[1] and 'X' in cells[2] and ' ' in cells[3]:
        return 3
    elif 'O' in cells[1] and 'O' in cells[2] and ' ' in cells[3]:
        return 3
    elif 'O' in cells[5] and ' ' in cells[6] and ' ' in cells[9]:
        return 9
    elif 'O' in cells[5] and 'O' in cells[4] and ' ' in cells[6]:
        return 6
    elif 'X' in cells[5] and 'X' in cells[3] and ' ' in cells[2]:
        return 2
    elif 'X' in cells[8] and 'X' in cells[5] and ' ' in cells[2]:
        return 2
    elif 'X' in cells[7] and 'X' in cells[5] and ' ' in cells[3]:
        return 3
    elif 'X' in cells[9] and 'X' in cells[5] and ' ' in cells[1]:
        return 1
    elif 'O' in cells[4] and 'O' in cells[5] and ' ' in cells[6]:
        return 6
    elif 'X' in cells[2] and 'X' in cells[5] and ' ' in cells[8]:
        return 8
    elif 'X' in cells[2] and 'X' in cells[3] and ' ' in cells[1]:
        return 1
    elif 'X' in cells[7] and 'X' in cells[5] and ' ' in cells[3]:
        return 3
    elif ' ' in cells[1]:
        return 1
    else:
        index = random.randint(1,9)
        return index

x_score = 0
o_score = 0
games = 1
while True: # ensures the game can continue for as many times as the player(s) want
    cells_init = [' ',' ',' ',' ',' ',' ',' ',' ',' ',' ']
    cells = cells_init
    reset()
    print(f'\nGame {games}')
    players = int(input('\nWill you be playing with a partner or will you take on the COMPUTER? \nPlayers(1 or 2)> '))
    if players == 1:
        player1 = input('\nPlease enter the name of Player 1:\nPlayer 1> ')
        difficulty = input('\nWould you like to take on the Easy or the Hard version of the COMPUTER? (E or H)\nDIFFICULTY> ')
    elif players == 2:
        player1 = input('Please enter the name of Player 1:\nPlayer 1> ')
        player2 = input('Please enter the name of Player 2:\nPlayer 2> ')

    while True: 
        ''' ensures the game can loop through without the initial questions, ensures the player
        names are stored as well as their scores and game numbers'''
        winner = False
        if games >= 2:  #Displays scores only after the second game
            cells_init = [' ',' ',' ',' ',' ',' ',' ',' ',' ',' ']
            cells = cells_init
            print(f'\nWelcome to game {games}!')
            print(f'\nGame {games}')
            if players == 1:
                print(f"{player1}'s score: {x_score}\nCOMPUTER's score: {o_score}")
            elif players == 2:
                print(f"{player1}'s score: {x_score}\n{player2}'s score: {o_score}")
        
        if players == 1:
            print('\n')
            display()
            while True: #loops through until it recieves a valid difficulty input and then until there is a winner
                diff = difficulty.lower()
                if diff == 'e': #will use easy bot for computer moves
                    avail = 0
                    while avail <= 9: #plays the game until there is a winner or until there are no more spaces on the board
                        update_x(get_xinput())
                        winner = check('X')
                        if winner == True:
                            break
                        avail += 1
                        if avail == 9:
                            break
                        print('\nThe COMPUTER is making a move...')
                        time.sleep(1.1)
                        update_o(easy_bot())
                        winner = check('O')
                        if winner == True:
                            break
                        avail += 1
                        print('\n')

                    #these statements check for a winner and then increases the score count if there is one then exits the loop that causes the game to execute
                    if check('O') == True:
                        print(f'\nThe COMPUTER beat {player1}! Better luck next time.')
                        o_score += 1
                        break
                    elif check('X') == True:
                        print(f'\nCongratulations! {player1}, has successfully defeated the COMPUTER!')
                        x_score += 1
                        break
                    elif avail == 9:
                        print(f"\nCAT! {player1} resulted to be a worthy opponent to the COMPUTER, but you've yet to beat it!")
                        break

                elif diff == 'h': # calls hard bot to make moves
                    avail = 0
                    while avail <= 9:
                        update_x(get_xinput())
                        winner = check('X')
                        if winner == True:
                            break
                        avail += 1
                        if avail == 9:
                            break
                        print('\nThe COMPUTER is making a move...')
                        
                        time.sleep(1.1)
                        update_o(hard_bot())
                        winner = check('O')
                        if winner == True:
                            break
                        avail += 1
                        print('\n')
                    
                    if check('O') == True:
                        print(f'\nThe COMPUTER beat {player1}! Better luck next time.')
                        o_score += 1
                        break
                    elif check('X') == True:
                        print(f'\nCongratulations! {player1}, has successfully defeated the COMPUTER!')
                        x_score += 1
                        break
                    elif avail == 9:
                        print(f"\nCAT! {player1} resulted to be a worthy opponent to the COMPUTER, but you've yet to beat it!")
                        break
                else: #keeps loop going until valid input is met
                    print('\nPlease select a valid difficulty option.')
                    difficulty = input('\nWould you like to take on the Easy or the Hard version of the COMPUTER? (E or H) \nDIFFICULTY> ')

        elif players == 2: #game will ask each player to provide an input
            avail = 0
            print('\n')
            display()
            while avail  <= 9:
                update_x(get_xinput())
                winner = check('X')
                if winner == True:
                    break
                avail += 1
                if avail == 9:
                    print(f"\nCAT! {player1} and {player2} have run out of moves")
                    break
                print('\n')
                update_o(get_oinput())
                winner = check('O')
                if winner == True:
                    break
                avail += 1
                if avail == 9:
                    print(f"\nCAT! {player1} and {player2} have run out of moves")
                    break
                print('\n')
                
            if check('O') == True:
                print(f'\n{player2} won! Congratulations')
                o_score += 1
            elif check('X') == True:
                print(f'\n{player1} won! Congratulations')
                x_score += 1
        else:
            print('Please enter a valid number of players, 2 players max')
            players = int(input('\nWill you be playing with a partner or will you take on the COMPUTER? \nPlayers(1 or 2)> '))

        while True: #loops through until proper input is met
            if ((check('O') or check('X')) == True) or (avail == 9):
                choice = input('\nWould you like to play again, Y or N? \nChoice> ')
                opt = choice.lower()
                if choice == 'y':
                    games += 1
                    break
                elif choice == 'n':
                    break
                else:
                    print('Please enter a valid choice Y or N.')
        if choice == 'n': #breaks from loop that 'remembers' scores and players
            break
    break #exits the game entirely
                
